class Medicament {
  int? id;
  String nom; // or name, choose one
  String posologie;
  String dateD;
  String dosage;
  double prix;
  String dateP;
  int nbrPacket;
  int? idOrd;

  Medicament({
    this.id,
    required this.nom, // or name, choose one
    required this.posologie,
    required this.dateD,
    required this.dosage,
    required this.prix,
    required this.dateP,
    required this.nbrPacket,
    this.idOrd,
  });

  // Convert a Medicament object into a Map
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'nom': nom, // or name, choose one
      'posologie': posologie,
      'dateD': dateD,
      'dosage': dosage,
      'prix': prix,
      'dateP': dateP,
      'nbrPacket': nbrPacket,
      'idOrd': idOrd,
    };
  }

  // Convert a Map into a Medicament object
  factory Medicament.fromMap(Map<String, dynamic> map) {
    return Medicament(
      id: map['id'],
      nom: map['nom'], // or name, choose one
      posologie: map['posologie'],
      dateD: map['dateD'],
      dosage: map['dosage'],
      prix: map['prix'],
      dateP: map['dateP'],
      nbrPacket: map['nbrPacket'],
      idOrd: map['idOrd'],
    );
  }

  factory Medicament.fromJson(Map<String, dynamic> json) {
    return Medicament(
      id: json['id'] as int?,
      nom: json['nom'], // or name, choose one
      posologie: json['posologie'],
      dateD: json['dateD'],
      dosage: json['dosage'],
      prix: json['prix'],
      dateP: json['dateP'],
      nbrPacket: json['nbrPacket'],
      idOrd: json['idOrd'],
    );
  }
}
