import 'package:flutter/material.dart';
import 'database_helper.dart';
//import 'medicament.dart';

class AjoutMedicament extends StatefulWidget {
  @override
  _AjoutMedicamentState createState() => _AjoutMedicamentState();
}

class _AjoutMedicamentState extends State<AjoutMedicament> {
  late DatabaseHelper dbHelper;
  late TextEditingController nomController;
  late TextEditingController dosageController;

  @override
  void initState() {
    super.initState();
    dbHelper = DatabaseHelper as DatabaseHelper; // Use the singleton instance
    nomController = TextEditingController();
    dosageController = TextEditingController();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add Medicament'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: nomController,
              decoration: InputDecoration(labelText: 'Nom'),
            ),
            TextField(
              controller: dosageController,
              decoration: InputDecoration(labelText: 'Dosage'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () async {
                print("Adding a new medicament...");
                await dbHelper.insertMedicament(
                  Medicament(
                    nom: nomController.text,
                    dosage: dosageController.text,
                    dateD: DateTime.now().toString(),
                    dateP: DateTime.now().toString(),
                    prix: 0.0,
                    nbrPacket: 0,
                    posologie: "", // Assuming you have a default value for posologie
                  ),
                );
                print("Medicament added successfully!");

                // Navigate back to the list of medicaments
                Navigator.pop(context);
              },
              child: Text('Add Medicament'),
            ),
          ],
        ),
      ),
    );
  }
}
